#!/usr/bin/python3

import argparse      # Input arguments parsing
import glob          # Path operations
import os            # Path operations
import pandas as pd  # DataFrame etc.
import re            # regex for string matching

########################################################################################################
## String Operations
def find_between(s: str, first: str, last: str) -> str:
    try:
        start = s.index(first) + len(first)
        end = s.index(last, start)
        return s[start:end]
    except ValueError:
        return ""

def get_space_separated(s: str) -> str:
   return " ".join(s.split())

def substring_after(s, delim):
    return s.partition(delim)[2]

########################################################################################################
## Dictionary/List Operations
def add_entry_to_dict_if_not_null(dct: dict, entry, key: str):
   if all(v is not None for v in [entry, key]):
      dct[key].append(entry)

def add_to_dict(dct: dict, entry1: str, entry2: int, col1="Procedure Name", col2="Total Time [s]"):
   add_to_dict(entry1=entry1, entry2=entry2, col1=col1, col2=col2, entry3=None, col3=None, entry4=None, col4=None, entry5=None, col5=None)

def add_to_dict(dct: dict, entry1: str, entry2: int, entry3: float, entry4: float, entry5: float, col1="Procedure Name", col2="Total Time [s]", col3="PC Setup Time [s]", col4="Krylov Method Time [s]", col5="Problem Total Time [s]"):
   dct[col1].append(entry1)
   dct[col2].append(entry2)
   add_entry_to_dict_if_not_null(dct, entry3, col3)
   add_entry_to_dict_if_not_null(dct, entry4, col4)
   add_entry_to_dict_if_not_null(dct, entry5, col5)

def init_dict(col1="Procedure Name", col2="Total Time [s]", col3="PC Setup Time [s]", col4="Krylov Method Time [s]", col5="Problem Total Time [s]") -> dict:
   return {col1: [], col2: [], col3: [], col4: [], col5: []}

def get_entries_matching(lst: list, regexes: list) -> list:
   return [entry for entry in lst if any(re.search(regex, entry) for regex in regexes)]

def strip_entries(lst: list):
   return [entry.strip() for entry in lst]

def get_index_of_first_entry_containing(lst: list, contents: str) -> int:
   return list(map(lambda line: contents in line, lst)).index(True)

def get_index_of_first_entry_matching(lst: list, regex: str) -> int:
   indices = [i for i, item in enumerate(lst) if re.search(regex, item)]
   return None if len(indices) == 0 else indices[0]

########################################################################################################
## Preconditioner/Problem Functions
def get_index_preconditioner_setup_begin(lst: list) -> int:
   return get_index_of_first_entry_containing(lst, "Preconditioner set-up ...")

def get_index_preconditioner_setup_end(lst: list) -> int:
   return get_index_of_first_entry_containing(lst, "Preconditioner set-up done.")

def get_preconditioner_setup_total_time(lst: list) -> float:
   index_pcsetup_total_time = get_index_of_first_entry_matching(lst, "^pc_setup[ ]+[0-9]+.[0-9]+[ ]s")
   total_time = find_between(lst[index_pcsetup_total_time], "pc_setup", "s")
   return float(total_time)

def get_problem_total_time(lst: list) -> float:
   index_problem_total_time = get_index_of_first_entry_matching(lst, "^total[ ]+[0-9]+.[0-9]+[ ]s")
   total_time = find_between(lst[index_problem_total_time], "total", "s")
   return float(total_time)

########################################################################################################
## Decomposer/Solver Name/Time
def get_procedure_name_from_first_entry_containing(lst: list, contents: str) -> str:
   first = next(filter(lambda entry: contents in entry, lst), None)
   procedure_name = find_between(first, "'", "'")
   return procedure_name

def get_time_from_entries_containing_interval(lst: list, contents: str, start: int, end: int) -> float:
   lst_context = [line for line in lst[start:end + 1] if contents in line]
   time = 0
   for entry in lst_context:
      time += float(find_between(get_space_separated(entry), ": ", " s"))
   return time

def get_time_from_entries_containing(lst: list, contents: str) -> float:
   return get_time_from_entries_containing_interval(lst, contents, 0, len(lst))

def get_decomposer_name(lst: list) -> str:
   name = get_procedure_name_from_first_entry_containing(lst, "Decomposing using ")
   return name

def get_decomposer_time(lst: list) -> int:
   return get_time_from_entries_containing(lst, "Time of dense LU factorization")

def get_decomposer_name_time(lst: list) -> tuple: # str, float
   return (get_decomposer_name(lst), get_decomposer_time(lst))

def get_ICM_processing_tolerance(lst: list) -> str:
   index_first_ICM_process_tol = get_index_of_first_entry_matching(lst, "^Using processing tolerance = ")
   if index_first_ICM_process_tol is not None:
      index_process_tol_in_line = lst[index_first_ICM_process_tol].index("= ") + 2
      return str(lst[index_first_ICM_process_tol][index_process_tol_in_line:])
   return None

def get_solver_name(lst: list) -> str:
   return get_procedure_name_from_first_entry_containing(lst, "Solving using ")

def get_solver_time_interval(lst: list, start: int, end: int) -> int:
   return get_time_from_entries_containing_interval(lst, "Time of dense LU backsubstitution", start, end)

def get_solver_time(lst: list) -> int:
   return get_solver_time_interval(lst, 0, len(lst))

def get_solver_name_time(lst: list) -> tuple: # str, float
   return (get_solver_name(lst), get_solver_time(lst))

def get_initial_solver_time(lst: list) -> tuple: # str, float
   return get_solver_time_interval(lst, get_index_preconditioner_setup_begin(lst), get_index_preconditioner_setup_end(lst))

########################################################################################################
## Krylov Method Functions
def get_index_krylov_begin(lst: list) -> int:
   return get_index_of_first_entry_containing(lst, "Calling Krylov method ...")

def get_index_krylov_end(lst: list) -> int:
   return get_index_of_first_entry_containing(lst, "Krylov method done.")

def get_index_krylov_iteration(lst: list, iteration) -> int:
   return get_index_of_first_entry_matching(lst, f"^KRYLOV_BDDCPCG:[ ]+iteration:[ ]+{iteration}$")

def get_krylov_num_pcg_iterations(lst: list) -> int:
   index_pcg_iterations = get_index_of_first_entry_containing(lst, "KRYLOV_BDDCPCG: Number of PCG iterations:")
   return int(get_space_separated(lst[index_pcg_iterations]).split("iterations: ", 1)[1])

def get_krylov_num_pcg_iterations_and_rel_residual_from_first_file_matching(files_dir: str, file_regex: str) -> tuple: # int, float
   first_file = get_files_in_dir_matching(files_dir, file_regex)[0]
   file_lines = strip_entries(get_file_lines_as_list(first_file))
   iterations = get_krylov_num_pcg_iterations(file_lines)
   return (iterations, get_krylov_iteration_residual(file_lines, iterations))

def get_krylov_time(lst: list) -> float:
   index_krylov_time = get_index_of_first_entry_matching(lst, "^Krylov method[ ]+[0-9]+.[0-9]+[ ]s")
   total_time = find_between(lst[index_krylov_time], "Krylov method", "s")
   return float(total_time)

def get_krylov_iteration_residual(lst: list, iteration: int, iteration_index: int = None) -> float:
   if iteration_index is None:
      iteration_index = get_index_krylov_iteration(lst, iteration)
   residual_line = lst[iteration_index + 1]
   return float(substring_after(residual_line, "residual:").strip())

def get_krylov_method_info(lst: list) -> tuple: #int, int, int
   return (get_index_krylov_begin(lst), get_index_krylov_end(lst), get_krylov_num_pcg_iterations(lst))

def get_lines_related_to_krylov(lst: list) -> list:
   krylov_start, krylov_end, _ = get_krylov_method_info(lst)
   return lst[krylov_start:krylov_end + 1]

def get_krylov_lu_backsubstitution_iteration_residual_lines(lst: list) -> tuple: # list, int
   krylov_lines = get_lines_related_to_krylov(lst)
   krylov_lines = get_entries_matching(krylov_lines, ["^Time of dense LU backsubstitution:[ ]+[0-9]+[.][0-9]+[ ]s$", \
                                                      "^KRYLOV_BDDCPCG:[ ]+iteration:[ ]+[0-9]+$", \
                                                      "^KRYLOV_BDDCPCG:[ ]+relative residual:[ ]+.*$"])
   return krylov_lines

def get_iteration_indices(lst: list, num_krylov_iterations: int) -> list: # tuple(int, int)
   indices = [(get_index_of_first_entry_matching(lst, "^Time of dense LU backsubstitution:[ ]+[0-9]+[.][0-9]+[ ]s$"), get_index_krylov_iteration(lst, 1))]
   for iteration in range(2, num_krylov_iterations + 1): # "+ 2" skips the line containing "residual"
      indices.append((get_index_krylov_iteration(lst, iteration - 1) + 2, get_index_krylov_iteration(lst, iteration)))
   return indices

def get_krylov_iteration_tuples(lst: list, num_krylov_iterations: int) -> list: # tuple(int, float, list)
   iterations_indices = get_iteration_indices(lst, num_krylov_iterations)
   iterations = []
   for iter, (iter_start, iter_end) in enumerate(iterations_indices, 1): # "- 1" bcs get_solver_time_interval includes the element at iter_end
      iterations.append((iter, get_krylov_iteration_residual(lst, iter, iter_end), get_solver_time_interval(lst, iter_start, iter_end - 1)))
   return iterations

def get_krylov_iterations(lst: list) -> list:
   krylov_lines = get_krylov_lu_backsubstitution_iteration_residual_lines(lst)
   krylov_iterations = get_krylov_iteration_tuples(krylov_lines, get_krylov_num_pcg_iterations(lst))
   return krylov_iterations

########################################################################################################
## File Operations
def get_file_lines_as_list(file_path) -> list:
   file = open(file_path,"r")
   return file.readlines()

def file_to_dataframe(file_path: str, procedure_type: str = "all", individual_backsubstitutions: bool = False) -> pd.DataFrame:
   file_lines = strip_entries(get_file_lines_as_list(file_path))

   benchmark_data = init_dict()
   # Get the Preconditioner setup time from the file
   pcsetup_time = get_preconditioner_setup_total_time(file_lines)
   # Get the Krylov method time from the file
   krylov_time = get_krylov_time(file_lines)
   # Get the Problem's total time from the file
   problem_total_time = get_problem_total_time(file_lines)

   if procedure_type in ["decomposers", "all"]:
      # Add Decomposer total time
      decomposer_name, decomposer_time = get_decomposer_name_time(file_lines)
      if "ICM" in decomposer_name:
         processing_tolerance_ICM = get_ICM_processing_tolerance(file_lines)
         if processing_tolerance_ICM is not None:
            decomposer_name += f" {processing_tolerance_ICM}"
      add_to_dict(benchmark_data, f"{decomposer_name}", decomposer_time, pcsetup_time, krylov_time, problem_total_time)

   if procedure_type in ["solvers", "all"]:
      # Add Solver total time
      solver_name, solver_time = get_solver_name_time(file_lines)
      add_to_dict(benchmark_data, f"{solver_name}", solver_time, pcsetup_time, krylov_time, problem_total_time)

      if individual_backsubstitutions:
         # Add initial Solver total time
         solver_initial_time = get_initial_solver_time(file_lines)
         add_to_dict(benchmark_data, f"{solver_name} - initial", solver_initial_time)
         # Add Krylov method backsubstitution times
         krylov_iterations = get_krylov_iterations(file_lines)
         for iter, residual, time in krylov_iterations:
            add_to_dict(benchmark_data, f"{solver_name} - iter: {iter}", time)

   return pd.DataFrame(benchmark_data)

def get_files_in_dir_matching(dir: str, regex_str: str) -> list:
   regex = re.compile(regex_str)
   matched_files = []
   for root, dirs, files in os.walk(dir):
      for file in files:
         if regex.match(file):
            matched_files.append(f"{dir}/{file}")
   return matched_files

def average_files_to_dataframe(files_dir: str, file_regex: str, procedure_type: str = "all") -> pd.DataFrame:
   file_list = get_files_in_dir_matching(files_dir, file_regex)
   if len(file_list) > 0:
      df_list = [file_to_dataframe(file, procedure_type) for file in file_list]
      # Get the mean and stddev of the total time and the pc setup time
      averaged_df = pd.concat(df_list).groupby('Procedure Name') \
                                      .agg({'Total Time [s]': ['mean', 'std'],
                                            'PC Setup Time [s]': ['mean', 'std'],
                                            'Krylov Method Time [s]': ['mean', 'std'],
                                            'Problem Total Time [s]': ['mean', 'std']}) \
                                      .reset_index()
      # The resulting df has extra row values below the headers "map, std" -> concatenate with the main header
      averaged_df.columns = averaged_df.columns.map(''.join)
      # Rename the columns to something more friendly
      averaged_df = averaged_df.rename(columns={'Total Time [s]mean': 'Procedure Total Time [s]',
                                                'Total Time [s]std': 'Procedure Std. Dev. [s]',
                                                'PC Setup Time [s]mean': 'PC Setup Time [s]',
                                                'PC Setup Time [s]std': 'PC Setup Std. Dev. [s]',
                                                'Krylov Method Time [s]mean': 'Krylov Method Time [s]',
                                                'Krylov Method Time [s]std': 'Krylov Method Std. Dev. [s]',
                                                'Problem Total Time [s]mean': 'Problem Total Time [s]',
                                                'Problem Total Time [s]std': 'Problem Total Std. Dev. [s]'})
      return averaged_df

def get_num_el_per_sub_edge(file_path: str) -> int:
   poisson_config = get_entries_matching(file_path.split("/"), ["^[0-9]+_[0-9]+_[0-9]+$"])[0]
   return int(poisson_config.split("_")[0])

def get_subdirectories(path: str) -> list:
   return [f.path for f in os.scandir(path) if f.is_dir()]

def get_procedure_type_from_path(path: str) -> str:
   return "decomposers" if "decomposers" in path.split("/") else "solvers"

def log_files_in_dir_tree_to_dataframe(dir: list, input_file_regex: str, procedure_type: str) -> pd.DataFrame:
   procedure_dirs = get_subdirectories(dir)

   average_dfs = []
   for procedure_dir in procedure_dirs:
      for poisson_config_dir in get_subdirectories(procedure_dir):
         df_avg = average_files_to_dataframe(poisson_config_dir, input_file_regex, procedure_type)
         df_avg.insert(0, "Num. el. per sub-edge", get_num_el_per_sub_edge(poisson_config_dir))
         pcg_iterations, rel_residual = get_krylov_num_pcg_iterations_and_rel_residual_from_first_file_matching(poisson_config_dir, input_file_regex)
         df_avg.insert(len(df_avg.columns) - 2, "Krylov PCG num. iters.", pcg_iterations)
         df_avg.insert(len(df_avg.columns) - 2, "Krylov PCG rel. residual", rel_residual)
         average_dfs.append(df_avg)
   return pd.concat(average_dfs).sort_values(by=["Num. el. per sub-edge", "Procedure Name"]).reset_index(drop=True)

def create_dir_for_output_files(dir: str) -> str:
   import shutil

   if "log-files" not in dir:
      print("-!> Directory 'dir' does not contain the expected 'log-files' substring -> not removing to be safe. Exiting...")
      exit(1)

   if os.path.exists(dir):
      shutil.rmtree(dir)

   print(f"-> Creating directory for parsed results: '{dir}'")
   os.mkdir(dir)
   return dir

########################################################################################################
## DataFrame operations
def compute_speedup_column(df: pd.DataFrame, baseline_procedure: str, time_column: str, output_column_prefix: str) -> pd.DataFrame:
   # Get the total time taken by baseline_procedure for each number of elements per sub-edge
   # Use the number of elements as the index
   baseline_times = df[df["Procedure Name"] == baseline_procedure].set_index("Num. el. per sub-edge")[time_column]

   # Compute and the speedup column for each procedure relative to the baseline_procedure
   df.insert(len(df.columns) - 6, f"{output_column_prefix} Speedup rel. to {baseline_procedure}", baseline_times.loc[df["Num. el. per sub-edge"]].values / df[time_column].values)
   return df

def save_to_plottable_csv(df: pd.DataFrame, output_file_path: str):
   """Save the dataframe to a CSV so that each procedure has columns for every metrics. This allows for easier plotting."""
   # Extract unique procedure names
   procedure_names = df['Procedure Name'].unique()

   # Create a dictionary to store the converted data
   converted_data = {}

   # Initialize the dictionary with empty lists for each procedure and each value
   for procedure_name in procedure_names:
      converted_data[procedure_name] = {key: [] for key in df.columns[2:]}

   # Populate the dictionary with data
   for _, row in df.iterrows():
      procedure_name = row['Procedure Name']
      procedure_values = row[2:]
      for key, value in zip(df.columns[2:], procedure_values):
         converted_data[procedure_name][key].append(value)

   # Create a new DataFrame with the converted data
   converted_df = pd.DataFrame()
   converted_df['Num. el. per sub-edge'] = df['Num. el. per sub-edge'].unique()
   for procedure_name in procedure_names:
      for key, values in converted_data[procedure_name].items():
         converted_df[f"{procedure_name} - {key}"] = values

   # Write the converted DataFrame to a new CSV file
   converted_df.to_csv(output_file_path, sep=',', encoding='utf-8', index=False)

def save_to_html(df: pd.DataFrame, output_file_path: str):
   text_file = open(output_file_path, "w")
   text_file.write(df.to_html())
   text_file.close()

########################################################################################################
## Matlab functions
def save_dataframe_plot(df: pd.DataFrame, title: str, y_col: str, dir: str, filename: str):
   import matplotlib.pyplot as plt

   fig, ax = plt.subplots(figsize=(10, 6))
   for procedure in df["Procedure Name"].unique():
      sub_df = df[df["Procedure Name"] == procedure]
      ax.plot(sub_df["Num. el. per sub-edge"], sub_df[y_col], linestyle="--")
      ax.scatter(sub_df["Num. el. per sub-edge"], sub_df[y_col], label=procedure)
   ax.set_title(title)
   ax.set_xlabel("Number of elements per sub-edge")
   ax.set_ylabel("Time [s]" )
   ax.legend()
   ax.grid(axis="y")
   ax.set_xticks(range(df["Num. el. per sub-edge"].min(), df["Num. el. per sub-edge"].max() + 1, 5))
   for i in range(df["Num. el. per sub-edge"].min(), df["Num. el. per sub-edge"].max() + 1, 5):
      ax.axvline(x=i, color="grey", alpha=0.5, linestyle="-")

   # Sanitize file name
   filename = filename.replace(' ', '-')

   plt.savefig(f"{dir}/{filename}.pdf")
   ax.set_yscale("log")
   ax.set_ylabel("Time [s] log-scaled" )

   plt.savefig(f"{dir}/{filename}-log.pdf")
   plt.savefig(f"{dir}/{filename}-log.png", dpi=200)

def save_time_plot(df: pd.DataFrame, time_column_prefix, procedure_type: str, dir: str):
   save_dataframe_plot(df, f"Comparison of {time_column_prefix} Time of {procedure_type} for poisson_on_cube problem", f"{time_column_prefix} Time [s]", dir, f"{procedure_type}_time_{time_column_prefix}")

def save_speedup_plot(df: pd.DataFrame, speedup_column_prefix: str, procedure_type: str, baseline_procedure: str, dir: str):
   save_dataframe_plot(df, f"Comparison of the {speedup_column_prefix} Speedup of {procedure_type} Relative to {baseline_procedure}", f"{speedup_column_prefix} Speedup rel. to {baseline_procedure}", dir, f"{procedure_type}_speedup_{speedup_column_prefix}")

########################################################################################################
## Arguments
def valid_arguments(args) -> bool:
   # Check existence of input file directory
   if not os.path.exists(args.procedures_dir):
      print(f"Directory '{args.procedures_dir}' not found!")
      return False

   # Check validity of regex
   try:
      re.compile(args.input_file_regex)
   except re.error:
      print("Invalid regex pattern!")
      return False

   # Check existence of output file directory
   if not os.path.exists(os.path.dirname(os.path.realpath(args.output_dir))):
      print(f"Directory of output file '{args.output_dir}' not found!")
      return False

   return True

def parse_arguments() -> tuple: # str, str
   # Parse arguments
   parser = argparse.ArgumentParser(description='Parse input file to load file_lines from.')

   # Required arguments
   requiredNamed = parser.add_argument_group('required named arguments')
   requiredNamed.add_argument('-d', '--procedures-dir', help='Directory containing the directories of procedures which hold their benchmark results.', required=True)
   requiredNamed.add_argument('-i', '--input-file-regex', help='Input file regex to match what files in the benchmark dirs to parse.', required=True)
   requiredNamed.add_argument('-o', '--output-dir', help='Output directory where the file containing benchmark results should be placed.', required=True)

   args = parser.parse_args()

   if not valid_arguments(args):
      print("Exiting...")
      parser.parse_args(['-h'])
      exit(1)

   return(args.procedures_dir, args.input_file_regex, args.output_dir)

########################################################################################################
## Main
def main():
   # Parse arguments
   procedures_dir, input_file_regex, output_dir = parse_arguments()
   procedure_type = get_procedure_type_from_path(procedures_dir)

   # Create dataframe with benchmark results parsed from multiple log files
   df = log_files_in_dir_tree_to_dataframe(procedures_dir, input_file_regex, procedure_type)

   # Compute the speedup relative to the existing decomposer/solver in BDDCML - MAGMAdgetrf_gpu/MAGMAdgetrs_gpu
   baseline_procedure = "MAGMAdgetrf_gpu" if procedure_type == "decomposers" else "MAGMAdgetrs_gpu"
   df = compute_speedup_column(df, baseline_procedure, "Procedure Total Time [s]", "Procedure")
   df = compute_speedup_column(df, baseline_procedure, "PC Setup Time [s]", "PC Setup")

   # Create a separate log directory for the parsed results
   dir = create_dir_for_output_files(f"{output_dir}/{procedure_type}/parsed_results")

   # Save the dataframe to a csv/html file
   save_to_plottable_csv(df, f"{dir}/{procedure_type}_benchmark_results_plottable.csv")
   save_to_html(df, f"{dir}/{procedure_type}_benchmark_results.html")

   # Save MATLAB plots
   print(df)
   save_time_plot(df, "Procedure Total", procedure_type, dir)
   save_time_plot(df, "PC Setup", procedure_type, dir)
   save_speedup_plot(df, "Procedure", procedure_type, baseline_procedure, dir)
   save_speedup_plot(df, "PC Setup", procedure_type, baseline_procedure, dir)


if __name__== "__main__" :
	main()