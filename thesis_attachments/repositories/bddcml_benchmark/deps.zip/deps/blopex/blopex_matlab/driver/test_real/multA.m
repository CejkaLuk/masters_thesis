function y = multA(x)
global operatorA
% multiplication by FEM stiffness matrix in operatorA
% for the demonstrative purpose only 
y = operatorA*x;
