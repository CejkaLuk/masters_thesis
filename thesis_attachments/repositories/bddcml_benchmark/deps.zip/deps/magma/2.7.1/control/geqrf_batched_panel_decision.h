#ifndef GEQRF_BATCHED_PANEL_DECISION
#define GEQRF_BATCHED_PANEL_DECISION

#include "geqrf_panel_decision_mi100.h"
#include "geqrf_panel_decision_a100.h"

#endif    // GEQRF_BATCHED_PANEL_DECISION