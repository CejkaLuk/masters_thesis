#include <stdio.h>

int main()
{
    int size = sizeof(void*);
    printf("%d\n", size);
    return 0;
}
