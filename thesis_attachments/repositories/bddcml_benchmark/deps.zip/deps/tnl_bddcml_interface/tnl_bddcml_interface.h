void tnl_create_and_set_matrix_on_gpu( int m, int n, double *A, int lda, void **dA);

void tnl_print_vector_int(int m, int *vec);

void tnl_print_vector_double(int m, double *vec);

void tnl_print_matrix_on_gpu(void **dA);

void tnl_clear_matrix_on_gpu(void **dA);

void tnl_gemv_matrix_on_gpu(int m, int n, void **dA, double *x, double *y);

void decomposer_on_gpu(int m, void **dA, int *piv, const int decomposer);

void solver_on_gpu(int m, int nrhs, void **dA, double *X, int *piv, const int decomposer, const int solver);