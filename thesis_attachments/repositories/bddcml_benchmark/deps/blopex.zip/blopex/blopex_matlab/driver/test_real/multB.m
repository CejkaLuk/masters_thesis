function y = multB(x)
global operatorB
% multiplication by FEM mass matrix in operatorB
% for the demonstrative purpose only 
y = operatorB*x;
