#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include "tnl_bddcml_interface.h"
#include <string.h>

void setupMatrix( int m, int n, double *hostMatrix)
{
   double val = 0.0;
   // Set-up host matrix and transposed matrix which will be transferred on the GPU
   for( int col = 0; col < n; col++ ) {
      for( int row = 0; row < m; row++ ) {
         hostMatrix[col*m+row] = val++;
      }
   }
}

void setupVector( int m, double *hostVector)
{
   double val = 1.0;
   // Set-up vector will be transferred to the GPU
   for( int row = 0; row < m; row++ ) {
      hostVector[row] = val++;
   }
}

void printVector_int( int m, int *hostVector)
{
   printf("vector = [ \n");
   for( int row = 0; row < m; row++ ) {
      printf("%d \n",hostVector[row]);
   }
   printf("]\n");
}

void printVector( int m, double *hostVector)
{
   printf("vector = [ \n");
   for( int row = 0; row < m; row++ ) {
      printf("%lf \n",hostVector[row]);
   }
   printf("]\n");
}

void setupSystem3LinEqs(int m, double *LU, double *B, double *X_expected)
{
   // AX = B
   // A = {  0, -3,  1 },
   //     {  1,  0,  1 },
   //     {  2,  1,  3 }
   // B = {  7,  8,  9 },
   //     {  6,  7,  8 },
   //     { 15, 16, 17 }
   // X = {  2,  3,  5 },
   //     { -1, -1, -2 },
   //     {  4,  3,  3 }
   assert(m == 3);

   // Column-major order
   int LU_orig[3*3] = {0, 1, 2, -3, 0, 1, 1, 1, 3};
   int B_orig[3*3] = {7, 6, 15, 8, 7, 16, 9, 8, 17};
   double X_orig[3*3] = {2, -1, 4, 3.5, -1.5, 3.5, 5, -2, 3};

   for(int row = 0; row < m; row++) {
      for(int col = 0; col < m; ++col) {
         LU[col*m+row] = LU_orig[col*m+row];
         B[col*m+row] = B_orig[col*m+row];
         X_expected[col*m+row] = X_orig[col*m+row];
      }
   }
}

void test_decomposition()
{
   printf("===========================================\n");
   printf("========== Testing Decomposition ==========\n");
   printf("===========================================\n");

   enum Decomposer {
      PCM8 = 0,
      PCM16,
      PCM32,
      ICM8,
      ICM16,
      ICM32,
      CuSolverDnXgetrf
   };

   enum Solver {
      IS8 = 0,
      IS16,
      IS32,
      IS64,
      IS128,
      CuBLAStrsm_U,
      CuBLAStrsm_L,
      CuSolverDnXgetrs
   };

   enum Decomposer decomposer = ICM8;
   enum Decomposer solver     = CuBLAStrsm_U;

   // Must be set to 3 for the example problem loaded by setupSystem3LinEqs()
   const int m = 3;
   const int nrhs = 3;

   // Variables
   void *deviceMatrix;
   double *hostMatrix;
   double *X;
   double *X_expected;
   int *piv;

   // Allocate memory
   hostMatrix = malloc(m*m*sizeof(double));
   X = malloc(m*nrhs*sizeof(double));
   X_expected = malloc(m*nrhs*sizeof(double));
   piv = malloc(m*sizeof(int));

   // Load values and create TNL matrix structure
   setupSystem3LinEqs(m, hostMatrix, X, X_expected);
   tnl_create_and_set_matrix_on_gpu(m, m, hostMatrix, m, &deviceMatrix);

   // Decomposer test
   printf("Testing Decomposer with partial pivoting on a %d x %d matrix...\n", m, m);
   printf(" A "); tnl_print_matrix_on_gpu(&deviceMatrix);
   printf(" piv "); tnl_print_vector_int(m, piv);
   decomposer_on_gpu(m, &deviceMatrix, piv, decomposer);
   printf(" LU "); tnl_print_matrix_on_gpu(&deviceMatrix);
   printf(" piv "); tnl_print_vector_int(m, piv);

   // Solver test
   // - Solve AX = B
   // - 'X' is initially used as 'B' (it holds the values of the right side on input)
   printf("Testing Solver with partial pivoting on a %d-linear-equation system...\n", m);
   printf(" B "); tnl_print_vector_double(m*nrhs, X);
   solver_on_gpu(m, nrhs, &deviceMatrix, X, piv, decomposer, solver);
   printf(" X_computed "); tnl_print_vector_double(m*nrhs, X);
   printf(" X_expected "); tnl_print_vector_double(m*nrhs, X_expected);

   // Free memory
   tnl_clear_matrix_on_gpu(&deviceMatrix);
   free(hostMatrix);
   free(X);
   free(piv);
   printf("===========================================\n");
}

int main( int argc, char* argv[] )
{
   // test repeated y = A*x
   const int m = 3;
   const int n = 3;
   const int matrixIterations = 2;

   void *deviceMatrix;
   double *hostMatrix;
   double *x, *y;

   hostMatrix = malloc(m*n*sizeof(double));

   setupMatrix(m, n, hostMatrix);

   x = malloc(n*sizeof(double));
   y = malloc(m*sizeof(double));

   // Sequential test
   printf("Testing TNL's GEMV...\n");
   tnl_create_and_set_matrix_on_gpu(m, n, hostMatrix, m, &deviceMatrix);

   for (int iter = 0; iter < matrixIterations; iter++) {
      setupVector(n, x);
      tnl_gemv_matrix_on_gpu(m, n, &deviceMatrix, x, y);
      printVector(m, y);
   }

   tnl_clear_matrix_on_gpu(&deviceMatrix);

   free(x);
   free(y);
   free(hostMatrix);

   // Decomposition test
   test_decomposition();
}
