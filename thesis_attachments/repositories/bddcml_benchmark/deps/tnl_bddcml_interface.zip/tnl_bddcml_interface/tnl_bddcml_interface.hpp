#include <assert.h>

#include <TNL/Matrices/DenseMatrix.h>

#include <Decomposition/Containers/MatrixFormat.h>

#include <Decomposition/LU/Decomposers/CroutMethod.h>
#include <Decomposition/LU/Decomposers/IterativeCroutMethod.h>
#include <Decomposition/LU/Decomposers/CuSolverDnXgetrfWrapper.h>

#include <Decomposition/LU/Solvers/IterativeSolver.h>
#include <Decomposition/LU/Solvers/CuBLAStrsmWrapper.h>
#include <Decomposition/LU/Solvers/CuSolverDnXgetrsWrapper.h>

// #define HAVE_CUDA

typedef TNL::Matrices::DenseMatrixView<
   double, TNL::Devices::Host, int, TNL::Algorithms::Segments::ColumnMajorOrder > MatrixHostView;
typedef TNL::Matrices::DenseMatrix< double, TNL::Devices::Cuda, int >  MatrixGPU;

using MatrixFormat = Decomposition::Containers::MatrixFormat;

extern "C"
void tnl_create_and_set_matrix_on_gpu( int m, int n, double *A, int lda, void **dA)
{
   TNL::Containers::VectorView< double > host_matrix_values;
   host_matrix_values.bind(A, m*n);

   MatrixHostView host_matrix_view(m, n, host_matrix_values);

   MatrixGPU *matrixDevice = new MatrixGPU();
   matrixDevice->setDimensions(n, m);

   try {
      *matrixDevice = host_matrix_view;
   } catch( ... ) {};

   *dA = static_cast<void *>(matrixDevice);
}

template< typename Real >
void tnl_print_vector(int m, Real *vec)
{
   TNL::Containers::VectorView< Real > vec_host;
   vec_host.bind(vec, m);

   std::cout << "vector = " << vec_host << std::endl;
}

extern "C"
void tnl_print_vector_int(int m, int *vec)
{
   tnl_print_vector(m, vec);
}

extern "C"
void tnl_print_vector_double(int m, double *vec)
{
   tnl_print_vector(m, vec);
}

template< typename Matrix >
void printMatrix(Matrix& mtx)
{
   printf("matrix = \n");
   for( int row = 0; row < mtx.getRows(); ++row ) {
      for( int col = 0; col < mtx.getColumns(); ++col ) {
         printf("%f ", mtx.getElement(row, col));
      }
      printf("\n");
   }
}

extern "C"
void tnl_print_matrix_on_gpu(void **dA)
{
   MatrixGPU *matrixDevice = static_cast<MatrixGPU *>(*dA);

   printMatrix(*matrixDevice);
}

extern "C"
void tnl_clear_matrix_on_gpu(void **dA)
{
   MatrixGPU *matrixDevice = static_cast<MatrixGPU *>(*dA);

   delete matrixDevice;
}

extern "C"
void tnl_gemv_matrix_on_gpu(int m, int n, void **dA, double *x, double *y)
{
   MatrixGPU *matrixDevice = static_cast<MatrixGPU *>(*dA);

   typedef TNL::Containers::VectorView< double, TNL::Devices::Host, int > VectorHostView;
   typedef TNL::Containers::Vector< double, TNL::Devices::Cuda, int >     VectorGPU;

   assert(m == matrixDevice->getRows());
   assert(n == matrixDevice->getColumns());

   VectorHostView x_host(x, n);
   VectorHostView y_host(y, m);
   VectorGPU dx(n), dy(m);

   try {
      dx = x_host; // copy vector to GPU
      dy = 0.;
      matrixDevice->vectorProduct(dx, dy);
      y_host = dy; // copy vector from GPU
   } catch( ... ) { std::cout << "Multiplication on GPU not succesfull." << std::endl;};
}

template< typename Decomposer, typename Matrix, typename Vector >
void call_decomposer(Matrix& LU, Vector& piv)
{
   std::cout << "Decomposing using '" << Decomposer::template getDecomposerName< typename Matrix::DeviceType >(!piv.empty()) << "'" << std::endl;
   Decomposer::decompose(LU, piv);
}

template< typename Matrix, typename VectorView >
void launch_decomposer(const int decomposer, Matrix& LU, VectorView& piv_host)
{
   using namespace Decomposition::LU::Decomposers;

   // Decomposers and which matrix format they produce:
   // 0-2 -> Parallel Crout Method  (8, 16, 32) => UnitDiagIn_U
   // 3-5 -> Iterative Crout Method (8, 16, 32) => UnitDiagIn_U
   // 6   -> CuSolverDnXgetrfWrapper            => UnitDiagIn_L
   switch(decomposer) {
      case 0:
         call_decomposer< CroutMethod<  8 > >(LU, piv_host);
         break;
      case 1:
         call_decomposer< CroutMethod< 16 > >(LU, piv_host);
         break;
      case 2:
         call_decomposer< CroutMethod< 32 > >(LU, piv_host);
         break;
      case 3:
         call_decomposer< IterativeCroutMethod<  8 > >(LU, piv_host);
         break;
      case 4:
         call_decomposer< IterativeCroutMethod< 16 > >(LU, piv_host);
         break;
      case 5:
         call_decomposer< IterativeCroutMethod< 32 > >(LU, piv_host);
         break;
      case 6:
      {
         // Using int64_t as it is required by CuSolverDnXgetrf
         typedef TNL::Containers::Vector< int64_t, TNL::Devices::Cuda, int64_t > CudaVector;
         CudaVector piv_cuda(piv_host.getSize(), 0);
         call_decomposer< CuSolverDnXgetrfWrapper >(LU, piv_cuda);
         piv_host = piv_cuda; // copy pivoting vector from the GPU
         break;
      }
      default:
         std::cout << "Unknown decomposer '" << decomposer << "'. Exiting..." << std::endl;
         std::exit(1);
   }
}

extern "C"
void decomposer_on_gpu(int m, void **dA, int *piv, const int decomposer)
{
   typedef TNL::Containers::VectorView< int, TNL::Devices::Host, int > HostVectorView;
   HostVectorView piv_host(piv, m);

   MatrixGPU *matrixDevice = static_cast<MatrixGPU *>(*dA);

   assert(m == matrixDevice->getRows());

   try {
      launch_decomposer(decomposer, *matrixDevice, piv_host);
   } catch( const std::exception& e ) {
      std::cout << "Decomposition on GPU not successful." << std::endl;
      std::cout << "Caught exception '" << e.what() << "'.";
   };
}

template< typename Solver, typename Matrix, typename Vector >
void call_solver(Matrix& LU, Matrix& X, Vector& piv)
{
   std::cout << "Solving using '" << Solver::template getSolverName< typename Matrix::DeviceType >(!piv.empty()) << "'" << std::endl;
   Solver::solve(LU, X, piv);
}

template< typename Matrix, typename VectorView >
void launch_solver(const int decomposer, const int solver, Matrix& LU, Matrix& X, VectorView& piv_host)
{
   using namespace Decomposition::LU::Solvers;
   // Solvers and which matrix format they support:
   // 0-4 -> Iterative Solver (8, 16, 32, 64, 128) => UnitDiagIn_U
   // 5   -> CuBLAStrsmWrapper (U)                 => UnitDiagIn_U
   // 6   -> CuBLAStrsmWrapper (L)                 => UnitDiagIn_L
   // 7   -> CuSolverDnXgetrsWrapper               => UnitDiagIn_L
   if(decomposer <= 5) { // decomposers producing LU with MatrixFormat::UnitDiagIn_U
      switch(solver) {
         case 0:
            call_solver< IterativeSolver<   8, MatrixFormat::UnitDiagIn_U > >(LU, X, piv_host);
            break;
         case 1:
            call_solver< IterativeSolver<  16, MatrixFormat::UnitDiagIn_U > >(LU, X, piv_host);
            break;
         case 2:
            call_solver< IterativeSolver<  32, MatrixFormat::UnitDiagIn_U > >(LU, X, piv_host);
            break;
         case 3:
            call_solver< IterativeSolver<  64, MatrixFormat::UnitDiagIn_U > >(LU, X, piv_host);
            break;
         case 4:
            call_solver< IterativeSolver< 128, MatrixFormat::UnitDiagIn_U > >(LU, X, piv_host);
            break;
         case 5:
            call_solver< CuBLAStrsmWrapper< MatrixFormat::UnitDiagIn_U > >(LU, X, piv_host);
            break;
         default:
            std::cout << "Solvers 0 - 5 are only compatible with decomposers 0 - 5. Decomposer is '" << decomposer
                      << "' and solver is '" << solver << "'. Exiting..." << std::endl;
            std::exit(1);
      }
   } else if(decomposer >= 6 && decomposer <= 7) { // decomposers producing LU with MatrixFormat::UnitDiagIn_L
      switch(solver) {
         case 6:
            call_solver< CuBLAStrsmWrapper< MatrixFormat::UnitDiagIn_L > >(LU, X, piv_host);
            break;
         case 7:
         {
            // Using int64_t as it is required by CuSolverDnXgetrs
            typedef TNL::Containers::Vector< int64_t, TNL::Devices::Cuda, int64_t > CudaVector;
            CudaVector piv_cuda(piv_host.getSize());
            piv_cuda = piv_host;
            call_solver< CuSolverDnXgetrsWrapper< MatrixFormat::UnitDiagIn_L > >(LU, X, piv_cuda);
            break;
         }
         default:
            std::cout << "Solvers 6 - 7 are only compatible with decomposers 6 - 7. Decomposer is '" << decomposer
                      << "' and solver is '" << solver << "'. Exiting..." << std::endl;
            std::exit(1);
      }
   } else {
      std::cout << "Unknown decomposer '" << decomposer << "'. Exiting..." << std::endl;
      std::exit(1);
   }
}

extern "C"
void solver_on_gpu(int m, int nrhs, void **dA, double *X, int *piv, const int decomposer, const int solver)
{
   typedef TNL::Containers::VectorView< int, TNL::Devices::Host, int > HostVectorView;

   // Prepare A on GPU
   MatrixGPU *matrixDevice = static_cast<MatrixGPU *>(*dA);

   // Prepare X on GPU
   TNL::Containers::VectorView< double > X_host_vector;
   X_host_vector.bind(X, m*nrhs);

   MatrixHostView X_host(m, nrhs, X_host_vector);
   MatrixGPU X_cuda;
   TNL::Containers::VectorView< double, TNL::Devices::Cuda > X_cuda_vector;

   // Prepare RowOrderVector on GPU
   HostVectorView piv_host(piv, m);

   assert(m == matrixDevice->getRows());

   try {
      X_cuda = X_host;
      launch_solver(decomposer, solver, *matrixDevice, X_cuda, piv_host);
      X_cuda_vector.bind(X_cuda.getValues().getData(), m*nrhs);
      X_host_vector = X_cuda_vector;
   } catch( const std::exception& e ) {
      std::cout << "Solving the system on GPU not successful." << std::endl;
      std::cout << "Caught exception '" << e.what() << "'.";
   };
}
