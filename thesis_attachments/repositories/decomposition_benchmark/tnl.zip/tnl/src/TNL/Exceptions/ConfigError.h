// Copyright (c) 2004-2023 Tomáš Oberhuber et al.
//
// This file is part of TNL - Template Numerical Library (https://tnl-project.org/)
//
// SPDX-License-Identifier: MIT

// Implemented by: Jakub Klinkovsky

#pragma once

#include <stdexcept>

namespace TNL::Exceptions {

struct ConfigError : public std::runtime_error
{
   ConfigError( const std::string& msg ) : std::runtime_error( msg ) {}
};

}  // namespace TNL::Exceptions
